import { Injectable } from '@angular/core';
import { GlobalConfig } from './config.component';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  constructor(public cnf: GlobalConfig) { }

  getSiteConfigurations(): any {
    return this.cnf.getConfig;
  }
}
