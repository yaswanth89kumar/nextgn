export class GlobalConfig {

    public config = {
      apiURL : 'http://www.google.com', // API endpoint.
      retryCount : 5, // Number of times API trigger if failed.
      licenceKey : 'abcdefghijklmnop123@', // To authenticate client licence Key.
      idleTime : 20, // System idle time to authenticate again.
      logoURL : 'path to logo', // Retrieve Logo.
      // Add according to the functionality
    };

    getConfig(): any {
      return this.config;
    }
}
