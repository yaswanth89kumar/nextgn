import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  langs = ['en', 'ar'];
  browserlang: string;
  @Output() language: EventEmitter<string> = new EventEmitter<string>();

  constructor(private translateService: TranslateService) { }

  ngOnInit(): void {
    this.browserlang = this.translateService.getBrowserLang();
    this.language.emit(this.browserlang);
    if (this.langs.indexOf(this.browserlang) > -1) {
      this.translateService.setDefaultLang(this.browserlang);
    } else {
      this.translateService.setDefaultLang('en');
    }
  }

  public useLanguage(lang: string): void{
    this.translateService.setDefaultLang(lang);
    this.browserlang = lang;
    this.language.emit(lang);
  }

}
