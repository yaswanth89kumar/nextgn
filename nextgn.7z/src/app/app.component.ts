import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'NextGen';
  selectedLanguage = 'en';

  selectedLang(event: string): void {
    this.selectedLanguage = event;
  }
}
